from random import randint
import prompt

def main():
    print('What number is missing in the progression?')
    i = 0
    while i < 3:
        start_number = randint(1, 100)
        next_number = start_number
        arith_progression = ''
        step = randint(1, 5)
        miss = randint(1, 10)
        j = 1
        while j != 11:
            if j != miss:
                next_number += step
                arith_progression = (
                    arith_progression + " " + str(next_number)
                )
                j += 1
            else:
                next_number += step
                correct_answ = next_number
                arith_progression = (
                    arith_progression + " " + ".."
                )
                j += 1
        print(arith_progression)
        answ = prompt.integer('Your answer: ')
        if answ == correct_answ:
            print('Correct!')
            i += 1
        else:
            print(
                '"{0}" is wrong answer ;(. Correct answer was "{1}".\nLet`s try again, {2}'
                .format(answ, correct_answ, 'Paul')
                )
            return
    print("Congratulations, {0}!".format('Paul'))

main()